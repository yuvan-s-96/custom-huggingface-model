from flask import Flask, render_template, request
from transformers import GPT2LMHeadModel, GPT2Tokenizer

app = Flask(__name__)

class DecisionNode:
    def __init__(self, question, answer=None, children=None):
        self.question = question
        self.answer = answer
        self.children = children or {}

def build_decision_tree():
    # Define the decision tree structure
    root = DecisionNode("Is the issue related to a product?")
    root.children["Yes"] = DecisionNode("Is it a hardware or software issue?", children={
        "Hardware": DecisionNode("Is it a problem with the device connectivity?", children={
            "Yes": DecisionNode("Please check the cables and try reconnecting."),
            "No": DecisionNode("Please contact our hardware support team.")
        }),
        "Software": DecisionNode("Have you checked for software updates?", children={
            "Yes": DecisionNode("Please install the latest updates and see if the issue persists."),
            "No": DecisionNode("Please contact our software support team.")
        })
    })
    root.children["No"] = DecisionNode("Is the inquiry about billing or account information?", children={
        "Billing": DecisionNode("Please contact our billing department for assistance."),
        "Account Information": DecisionNode("Have you tried resetting your password?", children={
            "Yes": DecisionNode("If the issue persists, please contact our support team."),
            "No": DecisionNode("Please try resetting your password.")
        })
    })

    return root

decision_tree = build_decision_tree()

# Load GPT-2 model and tokenizer
tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
model = GPT2LMHeadModel.from_pretrained("gpt2")

def generate_ai_response(question):
    # Tokenize the input and generate a response using GPT-2
    input_ids = tokenizer.encode(question, return_tensors="pt")
    output = model.generate(input_ids, max_length=100, num_beams=5, no_repeat_ngram_size=2, top_k=50, top_p=0.95, early_stopping=True)
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    return response

def is_product_related(query):
    # Simple check for product-related keywords in the query
    product_keywords = ["product", "issue", "problem"]
    return any(keyword in query.lower() for keyword in product_keywords)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/', methods=['POST'])
def process_answer():
    user_input = request.form['answer']
    
    if is_product_related(user_input):
        # If the query is related to a product, use the decision tree
        return handle_product_related_query(user_input)
    else:
        # Handle out-of-context questions using the AI response
        ai_response = generate_ai_response(user_input)
        return render_template('index.html', question=ai_response, ai_response=True)

def handle_product_related_query(query):
    # Use the decision tree for product-related queries
    if query.lower() == "yes":
        node = decision_tree.children["Yes"]
        return render_template('index.html', question=node.question, answer=node.answer if not node.children else None)
    elif query.lower() == "no":
        node = decision_tree.children["No"]
        return render_template('index.html', question=node.question, answer=node.answer if not node.children else None)
    else:
        return render_template('index.html', question="Invalid answer. Please enter Yes or No.")

if __name__ == '__main__':
    app.run(debug=True)
